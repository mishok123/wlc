<?php

/**
 * Simple Machines Forum (SMF)
 *
 * @package SMF
 * @author Simple Machines https://www.simplemachines.org
 * @copyright 2025 Simple Machines and individual contributors
 * @license https://www.simplemachines.org/about/smf/license.php BSD
 *
 * @version 2.1.6
 */

if (!defined('SMF'))
	die('No direct access...');

if (!defined('SMF_UNICODE_VERSION'))
	define('SMF_UNICODE_VERSION', '17.0.0.0');

?>